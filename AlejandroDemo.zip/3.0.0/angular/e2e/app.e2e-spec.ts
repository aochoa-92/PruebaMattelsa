import { AlejandroDemoTemplatePage } from './app.po';

describe('abp-project-name-template App', function() {
  let page: AlejandroDemoTemplatePage;

  beforeEach(() => {
    page = new AlejandroDemoTemplatePage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
