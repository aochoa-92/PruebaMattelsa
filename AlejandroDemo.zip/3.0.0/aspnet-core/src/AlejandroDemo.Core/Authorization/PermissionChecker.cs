﻿using Abp.Authorization;
using AlejandroDemo.Authorization.Roles;
using AlejandroDemo.Authorization.Users;

namespace AlejandroDemo.Authorization
{
    public class PermissionChecker : PermissionChecker<Role, User>
    {
        public PermissionChecker(UserManager userManager)
            : base(userManager)
        {

        }
    }
}
