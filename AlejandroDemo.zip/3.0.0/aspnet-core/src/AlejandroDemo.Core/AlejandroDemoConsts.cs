﻿namespace AlejandroDemo
{
    public class AlejandroDemoConsts
    {
        public const string LocalizationSourceName = "AlejandroDemo";

        public const string ConnectionStringName = "Default";

        public const bool MultiTenancyEnabled = true;
    }
}