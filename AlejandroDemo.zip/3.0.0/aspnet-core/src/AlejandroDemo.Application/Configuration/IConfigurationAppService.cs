﻿using System.Threading.Tasks;
using AlejandroDemo.Configuration.Dto;

namespace AlejandroDemo.Configuration
{
    public interface IConfigurationAppService
    {
        Task ChangeUiTheme(ChangeUiThemeInput input);
    }
}