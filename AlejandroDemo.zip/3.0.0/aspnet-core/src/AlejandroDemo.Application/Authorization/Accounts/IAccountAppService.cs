﻿using System.Threading.Tasks;
using Abp.Application.Services;
using AlejandroDemo.Authorization.Accounts.Dto;

namespace AlejandroDemo.Authorization.Accounts
{
    public interface IAccountAppService : IApplicationService
    {
        Task<IsTenantAvailableOutput> IsTenantAvailable(IsTenantAvailableInput input);

        Task<RegisterOutput> Register(RegisterInput input);
    }
}
