﻿using System.Reflection;
using Abp.AutoMapper;
using Abp.Modules;
using Abp.Reflection.Extensions;
using AlejandroDemo.Authorization;

namespace AlejandroDemo
{
    [DependsOn(
        typeof(AlejandroDemoCoreModule), 
        typeof(AbpAutoMapperModule))]
    public class AlejandroDemoApplicationModule : AbpModule
    {
        public override void PreInitialize()
        {
            Configuration.Authorization.Providers.Add<AlejandroDemoAuthorizationProvider>();
        }

        public override void Initialize()
        {
            Assembly thisAssembly = typeof(AlejandroDemoApplicationModule).GetAssembly();
            IocManager.RegisterAssemblyByConvention(thisAssembly);

            Configuration.Modules.AbpAutoMapper().Configurators.Add(cfg =>
            {
                //Scan the assembly for classes which inherit from AutoMapper.Profile
                cfg.AddProfiles(thisAssembly);
            });
        }
    }
}