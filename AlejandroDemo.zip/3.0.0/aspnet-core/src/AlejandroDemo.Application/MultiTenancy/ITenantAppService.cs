﻿using Abp.Application.Services;
using Abp.Application.Services.Dto;
using AlejandroDemo.MultiTenancy.Dto;

namespace AlejandroDemo.MultiTenancy
{
    public interface ITenantAppService : IAsyncCrudAppService<TenantDto, int, PagedResultRequestDto, CreateTenantDto, TenantDto>
    {
    }
}
