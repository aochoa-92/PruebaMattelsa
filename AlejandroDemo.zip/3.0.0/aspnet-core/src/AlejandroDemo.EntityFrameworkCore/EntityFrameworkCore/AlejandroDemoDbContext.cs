﻿using Abp.Zero.EntityFrameworkCore;
using AlejandroDemo.Authorization.Roles;
using AlejandroDemo.Authorization.Users;
using AlejandroDemo.MultiTenancy;
using Microsoft.EntityFrameworkCore;

namespace AlejandroDemo.EntityFrameworkCore
{
    public class AlejandroDemoDbContext : AbpZeroDbContext<Tenant, Role, User, AlejandroDemoDbContext>
    {
        /* Define an IDbSet for each entity of the application */
        
        public AlejandroDemoDbContext(DbContextOptions<AlejandroDemoDbContext> options)
            : base(options)
        {

        }
    }
}
