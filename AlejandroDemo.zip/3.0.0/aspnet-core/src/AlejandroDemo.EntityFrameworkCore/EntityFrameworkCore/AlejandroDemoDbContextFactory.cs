﻿using AlejandroDemo.Configuration;
using AlejandroDemo.Web;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;

namespace AlejandroDemo.EntityFrameworkCore
{
    /* This class is needed to run "dotnet ef ..." commands from command line on development. Not used anywhere else */
    public class AlejandroDemoDbContextFactory : IDesignTimeDbContextFactory<AlejandroDemoDbContext>
    {
        public AlejandroDemoDbContext CreateDbContext(string[] args)
        {
            var builder = new DbContextOptionsBuilder<AlejandroDemoDbContext>();
            var configuration = AppConfigurations.Get(WebContentDirectoryFinder.CalculateContentRootFolder());

            AlejandroDemoDbContextConfigurer.Configure(builder, configuration.GetConnectionString(AlejandroDemoConsts.ConnectionStringName));

            return new AlejandroDemoDbContext(builder.Options);
        }
    }
}