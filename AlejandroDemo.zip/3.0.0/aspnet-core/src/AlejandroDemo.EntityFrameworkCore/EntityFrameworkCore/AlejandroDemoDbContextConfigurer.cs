using System.Data.Common;
using Microsoft.EntityFrameworkCore;

namespace AlejandroDemo.EntityFrameworkCore
{
    public static class AlejandroDemoDbContextConfigurer
    {
        public static void Configure(DbContextOptionsBuilder<AlejandroDemoDbContext> builder, string connectionString)
        {
            builder.UseSqlServer(connectionString);
        }

        public static void Configure(DbContextOptionsBuilder<AlejandroDemoDbContext> builder, DbConnection connection)
        {
            builder.UseSqlServer(connection);
        }
    }
}