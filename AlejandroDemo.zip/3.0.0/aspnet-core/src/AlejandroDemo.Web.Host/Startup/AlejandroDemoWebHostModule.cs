﻿using System.Reflection;
using Abp.Modules;
using Abp.Reflection.Extensions;
using AlejandroDemo.Configuration;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;

namespace AlejandroDemo.Web.Host.Startup
{
    [DependsOn(
       typeof(AlejandroDemoWebCoreModule))]
    public class AlejandroDemoWebHostModule: AbpModule
    {
        private readonly IHostingEnvironment _env;
        private readonly IConfigurationRoot _appConfiguration;

        public AlejandroDemoWebHostModule(IHostingEnvironment env)
        {
            _env = env;
            _appConfiguration = env.GetAppConfiguration();
        }

        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(AlejandroDemoWebHostModule).GetAssembly());
        }
    }
}
